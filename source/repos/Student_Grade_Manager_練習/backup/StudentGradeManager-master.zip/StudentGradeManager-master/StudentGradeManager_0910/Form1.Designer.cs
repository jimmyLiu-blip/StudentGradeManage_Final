﻿namespace StudentGradeManager_0910
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtStudentId = new System.Windows.Forms.TextBox();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.txtClassName = new System.Windows.Forms.TextBox();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.cmbStudents = new System.Windows.Forms.ComboBox();
            this.dgvStudents = new System.Windows.Forms.DataGridView();
            this.dgvGrades = new System.Windows.Forms.DataGridView();
            this.btnSaveStudent = new System.Windows.Forms.Button();
            this.btnAddGrade = new System.Windows.Forms.Button();
            this.lblAverageScore = new System.Windows.Forms.Label();
            this.lblScoreMax = new System.Windows.Forms.Label();
            this.lblScoreMin = new System.Windows.Forms.Label();
            this.btnGrade = new System.Windows.Forms.Button();
            this.listTop3 = new System.Windows.Forms.ListBox();
            this.btnGet3 = new System.Windows.Forms.Button();
            this.cmbSubjectStats = new System.Windows.Forms.ComboBox();
            this.btnSubjectStats = new System.Windows.Forms.Button();
            this.lblSubjectStatsResult = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrades)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(43, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "學號:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(43, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "姓名:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(43, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "班級:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(378, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "學生列表:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(426, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "科目:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(426, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "分數:";
            // 
            // txtStudentId
            // 
            this.txtStudentId.Location = new System.Drawing.Point(126, 50);
            this.txtStudentId.Name = "txtStudentId";
            this.txtStudentId.Size = new System.Drawing.Size(133, 29);
            this.txtStudentId.TabIndex = 6;
            this.txtStudentId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtStudentName
            // 
            this.txtStudentName.Location = new System.Drawing.Point(126, 102);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(133, 29);
            this.txtStudentName.TabIndex = 7;
            this.txtStudentName.TextChanged += new System.EventHandler(this.txtStudentName_TextChanged);
            // 
            // txtClassName
            // 
            this.txtClassName.Location = new System.Drawing.Point(126, 153);
            this.txtClassName.Name = "txtClassName";
            this.txtClassName.Size = new System.Drawing.Size(133, 29);
            this.txtClassName.TabIndex = 8;
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(496, 100);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(133, 29);
            this.txtSubject.TabIndex = 9;
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(496, 151);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(133, 29);
            this.txtScore.TabIndex = 10;
            this.txtScore.TextChanged += new System.EventHandler(this.txtScore_TextChanged);
            // 
            // cmbStudents
            // 
            this.cmbStudents.FormattingEnabled = true;
            this.cmbStudents.Location = new System.Drawing.Point(496, 55);
            this.cmbStudents.Name = "cmbStudents";
            this.cmbStudents.Size = new System.Drawing.Size(133, 26);
            this.cmbStudents.TabIndex = 11;
            this.cmbStudents.SelectedIndexChanged += new System.EventHandler(this.cmbStudents_SelectedIndexChanged);
            // 
            // dgvStudents
            // 
            this.dgvStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudents.Location = new System.Drawing.Point(12, 197);
            this.dgvStudents.Name = "dgvStudents";
            this.dgvStudents.RowHeadersWidth = 62;
            this.dgvStudents.RowTemplate.Height = 31;
            this.dgvStudents.Size = new System.Drawing.Size(337, 224);
            this.dgvStudents.TabIndex = 12;
            this.dgvStudents.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dgvGrades
            // 
            this.dgvGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGrades.Location = new System.Drawing.Point(382, 197);
            this.dgvGrades.Name = "dgvGrades";
            this.dgvGrades.RowHeadersWidth = 62;
            this.dgvGrades.RowTemplate.Height = 31;
            this.dgvGrades.Size = new System.Drawing.Size(357, 224);
            this.dgvGrades.TabIndex = 13;
            // 
            // btnSaveStudent
            // 
            this.btnSaveStudent.Location = new System.Drawing.Point(283, 90);
            this.btnSaveStudent.Name = "btnSaveStudent";
            this.btnSaveStudent.Size = new System.Drawing.Size(84, 54);
            this.btnSaveStudent.TabIndex = 14;
            this.btnSaveStudent.Text = "新增";
            this.btnSaveStudent.UseVisualStyleBackColor = true;
            this.btnSaveStudent.Click += new System.EventHandler(this.btnSaveStudent_Click);
            // 
            // btnAddGrade
            // 
            this.btnAddGrade.Location = new System.Drawing.Point(644, 90);
            this.btnAddGrade.Name = "btnAddGrade";
            this.btnAddGrade.Size = new System.Drawing.Size(83, 54);
            this.btnAddGrade.TabIndex = 15;
            this.btnAddGrade.Text = "新增";
            this.btnAddGrade.UseVisualStyleBackColor = true;
            this.btnAddGrade.Click += new System.EventHandler(this.btnAddGrade_Click);
            // 
            // lblAverageScore
            // 
            this.lblAverageScore.AutoSize = true;
            this.lblAverageScore.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblAverageScore.Location = new System.Drawing.Point(795, 60);
            this.lblAverageScore.Name = "lblAverageScore";
            this.lblAverageScore.Size = new System.Drawing.Size(130, 24);
            this.lblAverageScore.TabIndex = 16;
            this.lblAverageScore.Text = "平均分數：";
            this.lblAverageScore.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblScoreMax
            // 
            this.lblScoreMax.AutoSize = true;
            this.lblScoreMax.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblScoreMax.Location = new System.Drawing.Point(795, 108);
            this.lblScoreMax.Name = "lblScoreMax";
            this.lblScoreMax.Size = new System.Drawing.Size(130, 24);
            this.lblScoreMax.TabIndex = 17;
            this.lblScoreMax.Text = "最高分數：";
            // 
            // lblScoreMin
            // 
            this.lblScoreMin.AutoSize = true;
            this.lblScoreMin.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblScoreMin.Location = new System.Drawing.Point(795, 156);
            this.lblScoreMin.Name = "lblScoreMin";
            this.lblScoreMin.Size = new System.Drawing.Size(130, 24);
            this.lblScoreMin.TabIndex = 18;
            this.lblScoreMin.Text = "最低分數：";
            // 
            // btnGrade
            // 
            this.btnGrade.Location = new System.Drawing.Point(1068, 90);
            this.btnGrade.Name = "btnGrade";
            this.btnGrade.Size = new System.Drawing.Size(107, 57);
            this.btnGrade.TabIndex = 22;
            this.btnGrade.Text = "計算";
            this.btnGrade.UseVisualStyleBackColor = true;
            this.btnGrade.Click += new System.EventHandler(this.button1_Click);
            // 
            // listTop3
            // 
            this.listTop3.FormattingEnabled = true;
            this.listTop3.ItemHeight = 18;
            this.listTop3.Location = new System.Drawing.Point(772, 263);
            this.listTop3.Name = "listTop3";
            this.listTop3.Size = new System.Drawing.Size(262, 76);
            this.listTop3.TabIndex = 23;
            this.listTop3.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnGet3
            // 
            this.btnGet3.Location = new System.Drawing.Point(1052, 292);
            this.btnGet3.Name = "btnGet3";
            this.btnGet3.Size = new System.Drawing.Size(134, 47);
            this.btnGet3.TabIndex = 24;
            this.btnGet3.Text = "查詢前3名";
            this.btnGet3.UseVisualStyleBackColor = true;
            this.btnGet3.Click += new System.EventHandler(this.btnGet3_Click);
            // 
            // cmbSubjectStats
            // 
            this.cmbSubjectStats.FormattingEnabled = true;
            this.cmbSubjectStats.Location = new System.Drawing.Point(1256, 130);
            this.cmbSubjectStats.Name = "cmbSubjectStats";
            this.cmbSubjectStats.Size = new System.Drawing.Size(133, 26);
            this.cmbSubjectStats.TabIndex = 25;
            this.cmbSubjectStats.SelectedIndexChanged += new System.EventHandler(this.cmbSubjectStats_SelectedIndexChanged);
            // 
            // btnSubjectStats
            // 
            this.btnSubjectStats.Location = new System.Drawing.Point(1422, 117);
            this.btnSubjectStats.Name = "btnSubjectStats";
            this.btnSubjectStats.Size = new System.Drawing.Size(101, 51);
            this.btnSubjectStats.TabIndex = 26;
            this.btnSubjectStats.Text = "查詢統計";
            this.btnSubjectStats.UseVisualStyleBackColor = true;
            this.btnSubjectStats.Click += new System.EventHandler(this.btnSubjectStats_Click);
            // 
            // lblSubjectStatsResult
            // 
            this.lblSubjectStatsResult.AutoSize = true;
            this.lblSubjectStatsResult.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblSubjectStatsResult.Location = new System.Drawing.Point(1259, 197);
            this.lblSubjectStatsResult.Name = "lblSubjectStatsResult";
            this.lblSubjectStatsResult.Size = new System.Drawing.Size(130, 24);
            this.lblSubjectStatsResult.TabIndex = 27;
            this.lblSubjectStatsResult.Text = "成績結果：";
            this.lblSubjectStatsResult.Click += new System.EventHandler(this.lblSubjectStatsResult_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1554, 430);
            this.Controls.Add(this.lblSubjectStatsResult);
            this.Controls.Add(this.btnSubjectStats);
            this.Controls.Add(this.cmbSubjectStats);
            this.Controls.Add(this.btnGet3);
            this.Controls.Add(this.listTop3);
            this.Controls.Add(this.btnGrade);
            this.Controls.Add(this.lblScoreMin);
            this.Controls.Add(this.lblScoreMax);
            this.Controls.Add(this.lblAverageScore);
            this.Controls.Add(this.btnAddGrade);
            this.Controls.Add(this.btnSaveStudent);
            this.Controls.Add(this.dgvGrades);
            this.Controls.Add(this.dgvStudents);
            this.Controls.Add(this.cmbStudents);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.txtSubject);
            this.Controls.Add(this.txtClassName);
            this.Controls.Add(this.txtStudentName);
            this.Controls.Add(this.txtStudentId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtStudentId;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.TextBox txtClassName;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.ComboBox cmbStudents;
        private System.Windows.Forms.DataGridView dgvStudents;
        private System.Windows.Forms.DataGridView dgvGrades;
        private System.Windows.Forms.Button btnSaveStudent;
        private System.Windows.Forms.Button btnAddGrade;
        private System.Windows.Forms.Label lblAverageScore;
        private System.Windows.Forms.Label lblScoreMax;
        private System.Windows.Forms.Label lblScoreMin;
        private System.Windows.Forms.Button btnGrade;
        private System.Windows.Forms.ListBox listTop3;
        private System.Windows.Forms.Button btnGet3;
        private System.Windows.Forms.ComboBox cmbSubjectStats;
        private System.Windows.Forms.Button btnSubjectStats;
        private System.Windows.Forms.Label lblSubjectStatsResult;
    }
}

